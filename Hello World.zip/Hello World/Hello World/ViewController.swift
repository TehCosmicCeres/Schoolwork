//
//  ViewController.swift
//  Hello World
//
//  Created by Ashton Armstrong on 3/1/1398 AP.
//  Copyright © 1398 Ashton Armstrong. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBAction func submitButton(_ sender: UIButton) {
        helloLabel.text = "Hello, " + nameBox.text!
    }
    
    @IBOutlet weak var nameBox: UITextField!
    @IBOutlet weak var helloLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

