//
//  ViewController.swift
//  Tip Calculator
//
//  Created by Student on 5/23/19.
//  Copyright © 2019 Texas State Technical College. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var tip:Double? = 0
    var actualBill:Double? = 0
    var actualTip:Double? = 0
    @IBOutlet weak var billAmount: UITextField!
    @IBOutlet weak var Slider: UISlider!
    @IBOutlet weak var tipAmount: UILabel!
    @IBOutlet weak var totalBill: UILabel!
    @IBOutlet weak var tipPercentage: UILabel!
    
    @IBAction func valueChanged(_ sender: UISlider) {
        let value = Int(sender.value)
        tipPercentage.text = "\(value)"
    }
    
    @IBAction func CalculateButton(_ sender: UIButton) {
        actualBill = Double(billAmount.text!)
        tip = Double(Slider.value) / 100
        actualTip = tip * actualBill
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

