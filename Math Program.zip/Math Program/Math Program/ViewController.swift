//
//  ViewController.swift
//  Math Program
//
//  Created by Ashton Armstrong on 3/8/1398 AP.
//  Copyright © 1398 Ashton Armstrong. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

