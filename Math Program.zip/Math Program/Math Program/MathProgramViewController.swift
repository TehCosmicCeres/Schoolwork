//
//  MathProgramViewController.swift
//  Math Program
//
//  Created by Ashton Armstrong on 3/8/1398 AP.
//  Copyright © 1398 Ashton Armstrong. All rights reserved.
//

import UIKit
class MathProgramViewController: UIViewController
{
    var firstNumVar:UInt32? = 0
    var secondNumVar:UInt32? = 0
    var symbolVar = "t"
    var symbolNum:UInt32 = 0
    var chance:Bool = false
    var correctAnswer:UInt32? = 0
    var answer:UInt32? = 0
    var winsVar:Int? = 0
    var lossesVar:Int? = 0
    
    

    @IBAction func makeNewProblem(_ sender: UIButton)
    {
        firstNumVar = arc4random() % 100
        secondNumVar = arc4random() % 100
        symbolNum = arc4random() % 4
        chance = true
        
        switch(symbolNum) {
        case 0:
            symbolVar = "+"
            correctAnswer = firstNumVar! + secondNumVar!
            firstNum.text = String(firstNumVar!)
            secondNum.text = String(secondNumVar!)
            symbol.text = symbolVar
        case 1:
            symbolVar = "-"
            if firstNumVar! > secondNumVar!
            {
                firstNum.text = String(firstNumVar!)
                secondNum.text = String(secondNumVar!)
                correctAnswer = firstNumVar! - secondNumVar!
                symbol.text = symbolVar
            }
            else
            {
                firstNum.text = String(secondNumVar!)
                secondNum.text = String(firstNumVar!)
                correctAnswer = secondNumVar! - firstNumVar!
                symbol.text = symbolVar
            }
        case 2:
            symbolVar = "*"
            correctAnswer = firstNumVar! * secondNumVar!
            firstNum.text = String(firstNumVar!)
            secondNum.text = String(secondNumVar!)
            symbol.text = symbolVar
        case 3:
            symbolVar = "/"
            while firstNumVar == 0 || secondNumVar == 0
            {
                if firstNumVar == 0
                {
                    firstNumVar = arc4random() % 100
                }
                
                if secondNumVar == 0
                {
                    secondNumVar = arc4random() % 100
                }
                
            }
            if firstNumVar! > secondNumVar!
            {
                firstNum.text = String(firstNumVar!)
                secondNum.text = String(secondNumVar!)
                correctAnswer = firstNumVar! / secondNumVar!
                symbol.text = symbolVar
            }
            else
            {
                firstNum.text = String(secondNumVar!)
                secondNum.text = String(firstNumVar!)
                correctAnswer = secondNumVar! / firstNumVar!
                symbol.text = symbolVar
            }
        default:
            symbol.text = "Error, please contact system admin."
        }
        
    }
    @IBAction func checkAnswer(_ sender: UIButton)
    {
        if chance == true
        {
            answer = UInt32(answerfield.text!)
            if answer == correctAnswer
            {
                declaration.text = "Correct, you got the answer right. You can play again, or not."
                winsVar = winsVar! + 1
                wins.text = String(winsVar!)
                chance = false
            }
            else
            {
                declaration.text = "Incorrect, you got the answer wrong. The actual answer is \(String(correctAnswer!)). Better luck next time, if you choose to play again."
                lossesVar = lossesVar! + 1
                losses.text = String(lossesVar!)
                chance = false
            }
        }
        else
        {
            declaration.text = "Please attempt to solve another problem before checking"
        }
    }
    
    @IBOutlet weak var firstNum: UILabel!
    @IBOutlet weak var symbol: UILabel!
    @IBOutlet weak var secondNum: UILabel!
    @IBOutlet weak var answerfield: UITextField!
    @IBOutlet weak var wins: UILabel!
    @IBOutlet weak var losses: UILabel!
    @IBOutlet weak var declaration: UILabel!
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?)
    {
        answerfield.endEditing(true)
    }
    override func viewDidLoad()
    {
        wins.text = String(winsVar!)
        losses.text = String(lossesVar!)
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
}
