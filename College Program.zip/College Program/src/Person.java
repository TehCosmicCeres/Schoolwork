import java.util.Scanner;
public class Person {
	 static String fName;
	 static String lName;
	 static String address;
	 static String phoneNum;
	 static int zipCode;
   
      Person(){
     }
      
      static void set(){
    	  Scanner input = new Scanner(System.in);
    	  System.out.println("Please enter the first name of this person.");
    	  fName = input.nextLine();
    	  System.out.println("Please enter the last name of this person.");
    	  lName = input.nextLine();
    	  System.out.println("Please enter the street address of this person.");
    	  address = input.nextLine();
    	  System.out.println("Please enter the phone number of this person.");
    	  phoneNum = input.nextLine();
    	  System.out.println("Please enter the zip code of this person.");
    	  zipCode = input.nextInt();
    	  input.nextLine();
    	  input.close();
      }
      
      static void get(){
    	  System.out.println("First Name:" + fName + " Last Name: " + lName + " Street Address: " + address + " Phone Number: " + phoneNum + " Zip Code: " + zipCode);
      }
}
