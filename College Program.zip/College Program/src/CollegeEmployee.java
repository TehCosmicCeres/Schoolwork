import java.util.Scanner;

public class CollegeEmployee extends Person {
	static String sSNum;
	static String salary;
	static String DepName;
	
	CollegeEmployee(){
		
	}
	
	static void set(){
  	  Scanner input = new Scanner(System.in);
  	  System.out.println("Please enter the first name of this college employee.");
  	  fName = input.nextLine();
  	  System.out.println("Please enter the last name of this college employee.");
  	  lName = input.nextLine();
  	  System.out.println("Please enter the street address of this college employee.");
  	  address = input.nextLine();
  	  System.out.println("Please enter the phone number of this college employee.");
  	  phoneNum = input.nextLine();
  	  System.out.println("Please enter the zip code of this college employee.");
  	  zipCode = input.nextInt();
  	  input.nextLine();
  	System.out.println("Please enter the salary of this college employee.");
	  salary = input.nextLine();
	  System.out.println("Please enter the social security number of this college employee.");
  	  sSNum = input.nextLine();
  	System.out.println("Please enter the department name of this college employee.");
	  DepName = input.nextLine();
  	  input.close();
    }
    
    static void get(){
  	  System.out.println("First Name:" + fName + " Last Name: " + lName + " Street Address: " + address + " Phone Number: " + phoneNum + " Zip Code: " + zipCode + " Salary: " + salary + " Social Security #: " + sSNum + " Department Name: " + DepName);
    }
}
