
public class CollegeEmployee {

}
