import java.util.Scanner;

public class CollegeList {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		boolean end = false;
		CollegeEmployee employeeArray[] = new CollegeEmployee[100];
		Faculty facultyArray[] = new Faculty[100];
		Student studentArray[] = new Student[100];
		int repNum = 0;
		
		while(end == false) {
			String inputChoice;
			String inputChoice2;
			String inputChoice3;
			CollegeEmployee emp;
			Faculty fac;
			Student stu;
			System.out.println("Would you like to enter information or display information?\n(e for enter, or d for display)");
			inputChoice = input.nextLine();
			
			if(inputChoice.equals("e")) {
				System.out.println("Would you like to enter the information for a college employee, faculty member, or a student?\n(enter c for employee, f for faculty member, or s for student)");
				inputChoice2 = input.nextLine();
				
				if(inputChoice2.equals("c")) {
					emp = new CollegeEmployee();
					emp.set();
					employeeArray[repNum] = emp;
				}
				
				else if(inputChoice2.equals("f")) {
					fac = new Faculty();
					fac.set();
					facultyArray[repNum] = fac;
				}
				
				else if(inputChoice2.equals("s")) {
					stu = new Student();
					stu.set();
					studentArray[repNum] = stu;
				}
				
				repNum++;
			
			
			}
			else if(inputChoice.equals("d")) {
				System.out.println("Would you like to display the information for a college employee, faculty member, or a student?\n(enter c for employee, f for faculty member, or s for student)");
				inputChoice2 = input.nextLine();
				
				if(inputChoice2.equals("c")) {
					for(int i = 0; i < employeeArray.length; i++) {
						if(employeeArray[i] != null) {
							employeeArray[i].get();
						}
					}
				}
				
				else if(inputChoice2.equals("f")) {
					for(int i = 0; i < facultyArray.length; i++) {
						if(facultyArray[i] != null) {
							facultyArray[i].get();
						}
					}
				}
				
				else if(inputChoice2.equals("s")) {
					for(int i = 0; i < studentArray.length; i++) {
						if(studentArray[i] != null) {
							studentArray[i].get();
						}
					}
				}
			}
			System.out.println("Would you like to keep inputting or displaying information?(y or n)");
			inputChoice3 = input.nextLine();
			if(inputChoice3.equals("y")) {
				
			}
			else {
				end = true;
			}
			input.close();
		}
	}
}
