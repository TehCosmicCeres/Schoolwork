
public class Faculty {

}
