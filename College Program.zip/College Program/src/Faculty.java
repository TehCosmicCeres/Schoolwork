import java.util.Scanner;

public class Faculty extends CollegeEmployee{
	static boolean isTenured = false;
	static String tenureChoice;
	
	
	static void set(){
	  	  Scanner input = new Scanner(System.in);
	  	  System.out.println("Please enter the first name of this faculty member.");
	  	  fName = input.nextLine();
	  	  System.out.println("Please enter the last name of this faculty member.");
	  	  lName = input.nextLine();
	  	  System.out.println("Please enter the street address of this faculty member.");
	  	  address = input.nextLine();
	  	  System.out.println("Please enter the phone number of this faculty member.");
	  	  phoneNum = input.nextLine();
	  	  System.out.println("Please enter the zip code of this faculty member.");
	  	  zipCode = input.nextInt();
	  	  input.nextLine();
	  	System.out.println("Please enter the salary of this faculty member.");
		  salary = input.nextLine();
		  System.out.println("Please enter the social security number of this faculty member.");
	  	  sSNum = input.nextLine();
	  	System.out.println("Please enter the department name of this faculty member.");
		  DepName = input.nextLine();
		  System.out.println("Is this faculty member tenured?.");
		  tenureChoice = input.nextLine();
		  if(tenureChoice.equals("y")) {
			  isTenured = true;
			  
		  }
	  	  input.close();
	    }
	    
	    static void get(){
	    	if(isTenured == true) {
	    		System.out.println("First Name:" + fName + " Last Name: " + lName + " Street Address: " + address + " Phone Number: " + phoneNum + " Zip Code: " + zipCode + " Salary: " + salary + " Social Security #: " + sSNum + " Department Name: " + DepName + " Is Tenured?: Yes");
	    	}
	    	else {
	    		System.out.println("First Name:" + fName + " Last Name: " + lName + " Street Address: " + address + " Phone Number: " + phoneNum + " Zip Code: " + zipCode + " Salary: " + salary + " Social Security #: " + sSNum + " Department Name: " + DepName + " Is Tenured?: No");
	    	}
	    }
}
