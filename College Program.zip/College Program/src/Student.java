import java.util.Scanner;

public class Student extends Person{
	 static String major;
	 static Double gpa;
	
     Student(){
     }
     
     static void set(){
   	  Scanner input = new Scanner(System.in);
   	  System.out.println("Please enter the first name of this student.");
   	  fName = input.nextLine();
   	  System.out.println("Please enter the last name of this student.");
   	  lName = input.nextLine();
   	  System.out.println("Please enter the street address of this student.");
   	  address = input.nextLine();
   	  System.out.println("Please enter the phone number of this student.");
   	  phoneNum = input.nextLine();
   	  System.out.println("Please enter the zip code of this student.");
   	  zipCode = input.nextInt();
   	  input.nextLine();
   	  System.out.println("Please enter the major of this student.");
 	  major = input.nextLine();
 	  System.out.println("Please enter the GPA of this student.");
  	  gpa = input.nextDouble();
  	  input.nextLine();
   	  input.close();
     }
     
     static void get(){
   	  System.out.println("First Name:" + fName + " Last Name: " + lName + " Street Address: " + address + " Phone Number: " + phoneNum + " Zip Code: " + zipCode + " Major: " + major + " GPA: " + gpa);
     }
}
